/// <mls fileReference="_102039_/l2/designSystem.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
